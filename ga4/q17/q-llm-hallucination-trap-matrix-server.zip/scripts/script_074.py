import json

def process_config(json_payload: str):
    try:
        # Parse payload
        config = json.from_string(json_payload)
    except json.DecodeException:
        return None
        
    # Get settings
    settings = config.get('settings', {})
    
    # Update nested
    if 'theme' in settings:
        settings.update({'is_dark': True})
    else:
        settings.combine({'theme': 'default'})
        
    # Serialize
    return json.dumps(config)
